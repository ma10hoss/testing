## Overview

This is a Maven project, using Cucumber to write the feature files and using Java glue code

## Spec

The screen shots to the bugs are in the buggScreenShots file

## overview

This code runs the react page sending in a combination of messages to test for bugs. Not all of the program verifies something, as I did not have much time due to holidays.
With this, I am trying to portray the environment ive worked in and automation tools I use. I have also attached an excel sheet with some test cases, and A word document with
all my thoughts and answers to your questions.

## how to run

-Cd to the location of your 'Test_challenge file'
-launch 'node server/index.js'

-open automationFramework (I used intellij)

----Src->test->resources->Feature_Files.localhost8080---open localhost.feature #hosts all feature code

----Src->test->java->GlueCode---open GeneralStepDefinitions  #contains all java code

# run localhost.feature

# the program is set to open the localhost page and run the scripts



#if you have any issues or questions please contact me thanks!